library(factoextra)
library(haven)

data <- readRDS("WVS_TimeSeries_4_0.rds")

colnames(data)

data[,29:945][data[,29:945]< 0] <- NA
data1 <- data[, c(5,23,29:945)]

country_period_data <- aggregate(.~COUNTRY_ALPHA + S020, data = data1, FUN = mean, na.action = na.pass, na.rm = TRUE)

country_period <- paste(country_period_data$COUNTRY_ALPHA,country_period_data$S020, sep = "_", collapse = NULL)
rownames(country_period_data) <- country_period

#Performing PCA on all periods

X <- X[,3:919]
X1 <- X[complete.cases(X),] #use complete rows only. 
X2 <- X[,complete.cases(t(X))] #use complete columns only. 
pca2 <- prcomp(X2, center = TRUE, scale. = TRUE)
fviz_pca_biplot(pca2, axes = c(1,3),
                repel = TRUE,
                col.var = "#2E9FDF", # Variables color
                col.ind = "#696969"  # Individuals color
)

fviz_pca_ind(pca2,
             col.ind = "cos2", # Color by the quality of representation
             gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"),
             repel = TRUE     # Avoid text overlapping
)

#Performing PCA on period 1 and extrapolating on period 2
X <- country_period_data[country_period_data$S020 >= 2010,]
Y <- X[X$S020 < 2016,3:919]
Z <- X[X$S020 >= 2016,3:919]
Y2 <- Y[,complete.cases(t(X[,3:919]))]
Z2 <- Z[,complete.cases(t(X[,3:919]))]

pca.y <- prcomp(Y2, center = TRUE, scale. = TRUE)
y_trans <- as.data.frame(predict(pca.y, Y2))
z_trans <- as.data.frame(predict(pca.y, Z2))

text(y_trans$PC1, y_trans$PC2, labels = rownames(y_trans), col = 'blue')
text(z_trans$PC1, z_trans$PC2, labels = rownames(z_trans), col = 'red')
