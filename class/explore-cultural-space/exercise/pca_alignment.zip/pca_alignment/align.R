library(factoextra)
library(haven)

data <- readRDS("WVS_TimeSeries_4_0.rds")

colnames(data)

data[,29:945][data[,29:945]< 0] <- NA
data1 <- data[, c(5,23,29:945)]

country_period_data <- aggregate(.~COUNTRY_ALPHA + S020, data = data1, FUN = mean, na.action = na.pass, na.rm = TRUE)

country_period <- paste(country_period_data$COUNTRY_ALPHA,country_period_data$S020, sep = "_", collapse = NULL)
rownames(country_period_data) <- country_period


X <- country_period_data[(country_period_data$S020 >= 2017)|((country_period_data$S020 <= 2014) & (country_period_data$S020 >= 2010)),]

X <- X[,3:919]
X1 <- X[complete.cases(X),] #use complete rows only. 
X2 <- X[,complete.cases(t(X))] #use complete columns only. 
pca2 <- prcomp(X2, center = TRUE, scale. = TRUE)
fviz_pca_biplot(pca2, axes = c(1,3),
                repel = TRUE,
                col.var = "#2E9FDF", # Variables color
                col.ind = "#696969"  # Individuals color
)

fviz_pca_ind(pca2,
             col.ind = "cos2", # Color by the quality of representation
             gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"),
             repel = TRUE     # Avoid text overlapping
)

