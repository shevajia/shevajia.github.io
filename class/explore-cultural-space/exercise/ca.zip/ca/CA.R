library(FactoMineR)
library(factoextra)
library(fastDummies)

data <- load("35536-0001-Data.rda")
attach(da35536.0001)

I <- read.csv("gss_culture_indicator.csv", row.names = 1)
CA(I, ncp = 5, graph = TRUE)
res.ca <- CA(I, graph = FALSE)
res.ca

get_eigenvalue(res.ca)

fviz_eig(res.ca)

fviz_ca_col(res.ca, repel = TRUE)
fviz_ca_biplot(res.ca)

fviz_screeplot(res.ca, addlabels = TRUE, ylim = c(0, 10))

#The codes above replicate the analysis we performed in Python. 
#In the section below, I should how to make use of additional supplementary variables that are not used in the construction of CA. 

#First, we need to drop rows that have all zeros. Because the data was generated in Python, the row labels start with 0 instead of 1. We need to add 1 back in order to match the row numbers in R. 
drop.rows <- c(167, 187, 594, 667, 854, 865, 1164, 1224, 1293, 1338, 1342) + 1



#In a biplot, we can show all individuals along with all variables. We can also color the individuals according to their years of education. 
fviz_ca_biplot(res.ca, col.col = 'black',
               col.row = EDUC[-drop.rows],
               gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"))

#In a biplot, let's also try to color the individuals according to their age.
fviz_ca_biplot(res.ca, col.col = 'black',
               col.row = AGE[-drop.rows],
               gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"))




#Next I want to infer the locations of the highest degree types (which are variables I did not use in the construction of CA) in the latent cultural space. 

DEGREE_ind <- dummy_cols(DEGREE)

I1 <- cbind(I, DEGREE_ind[2:6])
I2 <- I1[-drop.rows,]
I2 <- I2[complete.cases(I2),]
res.ca <- CA(I2, graph = FALSE, col.sup = 40:44)


fviz_ca_col(res.ca, repel = TRUE, col.col.sup = 'black')

#Let's try to do the same for age.
#We first need to create age dummies. 
AGE10 <- AGE %/% 10 #%/% is the operator for integer divide.
AGE10_ind <- dummy_cols(AGE10, remove_selected_columns = TRUE, ignore_na = TRUE)
#Rename the columns.
colnames(AGE10_ind) <- c('below 20', '20-29', '30-39' , '40-49', '50-59', '60-69', '70-79', '80-89')
I1 <- cbind(I, AGE10_ind)
I2 <- I1[-drop.rows,]
I2 <- I2[complete.cases(I2),]
res.ca <- CA(I2, graph = FALSE, col.sup = 40:47)
fviz_ca_col(res.ca, repel = TRUE, col.col.sup = 'black')






