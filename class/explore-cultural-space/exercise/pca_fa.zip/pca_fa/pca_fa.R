# For this exercise, we will use Seventh Wave of the World Value Survey. 
# First, read the data. 
data <- readRDS("WVS_Cross-National_Inverted_Wave_7_Rds_v5_0.rds")
# Check out what the data looks like. 
head(data)
summary(data)
summary(data$Q100)

# Attach the data so that all of its variables can be called directly. 
attach(data)
summary(Q100)
# Check out the attributes of some variables. 
attr(Q100, "label")
attr(Q100, "labels")

# Select data entries 
data[100,"Q1P"] # the 100th respondent's answer on Q1
data[10:20, "Q1P"] # the 10th-20th respondents' answers on Q1
selected_vars <- c("Q1P", "Q2P") # a vector containing selected variable names 
data[selected_vars] # read selected variables(rows) from the data
data[10:15,selected_vars] # read the 10th-15th respondents' answers on the selected variables 
data[10:15, 20:25] # treat the data as a matrix and read the 10th-15th rows and the 20th-25th columns. 

ARG_data <- data[B_COUNTRY == 32,] # select respondents from Argentina and store their responses in a new dataframe. 32 is the country code for Argentina. 

# Compute the mean, variance and standard deviation of a variable. 
mean(Q100)
var(Q100)
sd(Q100)

# Note that negative response values should be treated as missing. 
Q100[Q100 < 0] <- NA # replace all negative entries of a variable with NA 

# Now, let's re-compute the summary statistics. 
mean(Q100, na.rm = TRUE)
var(Q100, na.rm = TRUE)
sd(Q100, na.rm = TRUE)

# Get all variable names. 
colnames(data)

# Plot the frequency distribution of the responses to Q1
hist(Q1P)

# The unit of observation in the original dataset is individual. Next,we want to aggregate the data to the country level. 
# In this exercise, we only care about the respondents' opinions rather than their demographic information. It seems are Q1-Q259 are all opinion questions. We'll only work with these variables. They correspond to row 39 to 300. 
data[,39:300] 

# An efficient way to replace all negative entries as NA
data[,39:300][data[,39:300]< 0] <- NA

# To have country-level aggregate measures, we only need to have all the country ids and relevant questions. 
data1 <- data[, c(6,39:300)] # The 6th column gives the country ids. 
# Compute the correlation and covariance matrix of all the opinion variables. Because the data contains missing values, we'll use pairwise complete observations to compute each pair of correlation and covariance. Here, the unit of analysis is still the individual. 
correlation_matrix <- cor(data1[,2:263], use = "pairwise.complete.obs")
covariance_matrix <- cov(data1[,2:263], use = "pairwise.complete.obs")

# Now, we aggregate the data by country means. We'll ignore missing values when computing the country means. Some questions do not get answered in some countries at all. The country mean would be missing as well. We'll keep those countries. 
country_data <- aggregate(.~B_COUNTRY, data = data1, FUN = mean, na.action = na.pass, na.rm = TRUE)
?aggregate # If you are uncertain about how a function works, you can always use "?" to check out its user manual. 

# Now, we want to detach the original dataset and attach the country-level data. 
detach(data)
attach(country_data)

# Plot Q2 vs. Q! at the country-level. 
plot(Q1P, Q2P) # scatterplot
abline(lm(Q2P~Q1P), col="red") # add a regression line 
text(Q1P, Q2P, labels=names(attr(data$B_COUNTRY, 'labels')), cex= 0.6) # label the countries

# We want to give the country ids the same labels 
attr(country_data$B_COUNTRY, 'labels') <- attr(data$B_COUNTRY, 'labels')
# Save the country-level data for further use. 
saveRDS(country_data, "WVS_country_opinion.rds")





### PCA

#Uncomment the following line to install factoextra. You only need to install it once. 
#install.packages("factoextra") 
library(factoextra)

country_data <- readRDS("WVS_country_opinion.rds") #load the country-level data
attach(country_data)
X <- country_data[,2:263] #use everything from the data except for the first column. 

rownames(X) <- names(attr(B_COUNTRY, 'labels')) #name each row according to its corresponding country name.
write.csv(attr(B_COUNTRY, 'labels'), "country_labels.csv") #save the country names.
rownames(X) #display the row names. 

X1 <- X[complete.cases(X),] #use complete rows only. 
X2 <- X[,complete.cases(t(X))] #use complete columns only. 

X1_ctd <- scale(X1, center = TRUE) #mean-center a a dataframe.
colMeans(X1_ctd) #check that the column means are indeed zeros. 
X1_ctd_std <- scale(X1, center = TRUE, scale = TRUE) #mean-center and standardize a dataframe.
var(X1_ctd_std) #check that diagonal entries of the variance-covariance matrix are all 1s. 

pca1 <- prcomp(X1, center = TRUE, scale. = TRUE) #perform PCA on a matrix and save the results.
fviz_eig(pca1) #plot the eigenvalues. 
pca1$sdev > 1 #find all eigenvalues that are greater than 1. 

fviz_pca_ind(pca1,
             col.ind = "cos2", # Color by the quality of representation
             gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"),
             repel = TRUE     # Avoid text overlapping
) #produce a sample-pca plot. 

fviz_pca_var(pca1,
             col.var = "contrib", # Color by contributions to the PC
             gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07")
) #produce a variable-pca plot. 

fviz_pca_biplot(pca1, repel = TRUE,
                col.var = "#2E9FDF", # Variables color
                col.ind = "#696969"  # Individuals color
) #produce a biplot. 

# Get the eigenvalues
eig.val <- get_eigenvalue(pca1)
eig.val

# Results for Variables
res.var <- get_pca_var(pca1)
res.var$coord          # Coordinates
res.var$contrib        # Contributions to the PCs
res.var$cos2           # Quality of representation 
# Results for individuals
res.ind <- get_pca_ind(pca1)
res.ind$coord          # Coordinates
res.ind$contrib        # Contributions to the PCs
res.ind$cos2           # Quality of representation


# Repeat the same process for X2. 
pca2 <- prcomp(X2, center = TRUE, scale. = TRUE)
fviz_eig(pca2)
pca1$sdev > 1

eig.val <- get_eigenvalue(pca2)
eig.val

fviz_pca_ind(pca2,
             col.ind = "cos2", # Color by the quality of representation
             gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"),
             repel = TRUE     # Avoid text overlapping
)

fviz_pca_var(pca2,
             col.var = "contrib", # Color by contributions to the PC
             gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07")
)

fviz_pca_biplot(pca2, repel = TRUE,
                col.var = "#2E9FDF", # Variables color
                col.ind = "#696969"  # Individuals color
)


fviz_pca_biplot(pca2, axes = c(1,3),
                repel = TRUE,
                col.var = "#2E9FDF", # Variables color
                col.ind = "#696969"  # Individuals color
)


### Factor Analysis


library(psych)
library(GPArotation)

country_data <- read.csv('WVS_country_opinion_10.csv', row.names = 1)
KMO(country_data)

selected_data <- country_data[-7]
res.fa <- fa(selected_data, nfactors = 2, rotate = 'varimax', fm = 'pa')
res.fa


res.fa <- fa(selected_data, nfactors = 2, rotate = 'promax', fm = 'pa')
res.fa

biplot.psych(res.fa, labels = rownames(selected_data))
