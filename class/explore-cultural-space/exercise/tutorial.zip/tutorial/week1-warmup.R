# For this exercise, we will use the Seventh Wave of the World Value Survey. 
# First, read the data. 
data <- readRDS("WVS_Cross-National_Inverted_Wave_7_Rds_v5_0.rds")
# Check out what the data looks like. 
head(data)
summary(data)
summary(data$Q100)

# Attach the data so that all of its variables can be called directly. 
attach(data)
summary(Q100)
# Check out the attributes of some variables. 
attr(Q100, "label")
attr(Q100, "labels")

# Select data entries 
data[100,"Q1P"] # the 100th respondent's answer on Q1
data[10:20, "Q1P"] # the 10th-20th respondents' answers on Q1
selected_vars <- c("Q1P", "Q2P") # a vector containing selected variable names 
data[selected_vars] # read selected variables(rows) from the data
data[10:15,selected_vars] # read the 10th-15th respondents' answers on the selected variables 
data[10:15, 20:25] # treat the data as a matrix and read the 10th-15th rows and the 20th-25th columns. 

ARG_data <- data[B_COUNTRY == 32,] # select respondents from Argentina and store their responses in a new dataframe. 32 is the country code for Argentina. 

# Compute the mean, variance and standard deviation of a variable. 
mean(Q100)
var(Q100)
sd(Q100)

# Note that negative response values should be treated as missing. 
Q100[Q100 < 0] <- NA # replace all negative entries of a variable with NA 

# Now, let's re-compute the summary statistics. 
mean(Q100, na.rm = TRUE)
var(Q100, na.rm = TRUE)
sd(Q100, na.rm = TRUE)

# Get all variable names. 
colnames(data)

# Plot the frequency distribution of the responses to Q1
hist(Q1P)

# The unit of observation in the original dataset is individual. Next,we want to aggregate the data to the country level. 
# In this exercise, we only care about the respondents' opinions rather than their demographic information. It seems are Q1-Q259 are all opinion questions. We'll only work with these variables. They correspond to row 39 to 300. 
data[,39:300] 

# An efficient way to replace all negative entries as NA
data[,39:300][data[,39:300]< 0] <- NA

# To have country-level aggregate measures, we only need to have all the country ids and relevant questions. 
data1 <- data[, c(6,39:300)] # The 6th column gives the country ids. 
# Compute the correlation and covariance matrix of all the opinion variables. Because the data contains missing values, we'll use pairwise complete observations to compute each pair of correlation and covariance. Here, the unit of analysis is still the individual. 
correlation_matrix <- cor(data1[,2:263], use = "pairwise.complete.obs")
covariance_matrix <- cov(data1[,2:263], use = "pairwise.complete.obs")

# Now, we aggregate the data by country means. We'll ignore missing values when computing the country means. Some questions do not get answered in some countries at all. The country mean would be missing as well. We'll keep those countries. 
country_data <- aggregate(.~B_COUNTRY, data = data1, FUN = mean, na.action = na.pass, na.rm = TRUE)
?aggregate # If you are uncertain about how a function works, you can always use "?" to check out its user manual. 

# Now, we want to detach the original dataset and attach the country-level data. 
detach(data)
attach(country_data)

# Plot Q2 vs. Q! at the country-level. 
plot(Q1P, Q2P) # scatterplot
abline(lm(Q2P~Q1P), col="red") # add a regression line 
text(Q1P, Q2P, labels=names(attr(data$B_COUNTRY, 'labels')), cex= 0.6) # label the countries

# We want to give the country ids the same labels 
attr(country_data$B_COUNTRY, 'labels') <- attr(data$B_COUNTRY, 'labels')
# Save the country-level data for further use. 
saveRDS(country_data, "WVS_country_opinion.rds")




